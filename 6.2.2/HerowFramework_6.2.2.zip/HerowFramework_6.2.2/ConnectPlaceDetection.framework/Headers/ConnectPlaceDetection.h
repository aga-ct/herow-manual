//
//  ConnectPlaceDetection.h
//  ConnectPlaceDetection
//
//  Created by Ludovic Vimont on 22/12/2017.
//  
//  Copyright © 2017 Connecthings. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for ConnectPlaceDetection.
FOUNDATION_EXPORT double ConnectPlaceDetectionVersionNumber;

//! Project version string for ConnectPlaceDetection.
FOUNDATION_EXPORT const unsigned char ConnectPlaceDetectionVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <ConnectPlaceDetection/PublicHeader.h>
