//
//  ConnectPlaceBeaconDetection.h
//  ConnectPlaceBeaconDetection
//
//  Created by Olivier Stevens on 17/07/2017.
//  Copyright © 2017 Connecthings. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for ConnectPlaceBeaconDetection.
FOUNDATION_EXPORT double ConnectPlaceBeaconDetectionVersionNumber;

//! Project version string for ConnectPlaceBeaconDetection.
FOUNDATION_EXPORT const unsigned char ConnectPlaceBeaconDetectionVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <ConnectPlaceBeaconDetection/PublicHeader.h>


