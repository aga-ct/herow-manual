//
//  ConnectPlaceProvider.h
//  ConnectPlaceProvider
//
//  Created by Olivier Stevens on 04/07/2017.
//  Copyright © 2017 Connecthings. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for ConnectPlaceProvider.
FOUNDATION_EXPORT double ConnectPlaceProviderVersionNumber;

//! Project version string for ConnectPlaceProvider.
FOUNDATION_EXPORT const unsigned char ConnectPlaceProviderVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <ConnectPlaceProvider/PublicHeader.h>


