//
//  HerowAnalytics.h
//  HerowAnalytics
//
//  Created by Olivier Stevens on 15/09/2017.
//  Copyright © 2017 Connecthings. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for HerowAnalytics.
FOUNDATION_EXPORT double HerowAnalyticsVersionNumber;

//! Project version string for HerowAnalytics.
FOUNDATION_EXPORT const unsigned char HerowAnalyticsVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <HerowAnalytics/PublicHeader.h>


