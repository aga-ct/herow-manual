//
//  HerowLocationBeacon.h
//  HerowLocationBeacon
//
//  Created by Connectings on 11/09/2017.
//  Copyright © 2017 Connecthings. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for HerowLocationBeacon.
FOUNDATION_EXPORT double HerowLocationBeaconVersionNumber;

//! Project version string for HerowLocationBeacon.
FOUNDATION_EXPORT const unsigned char HerowLocationBeaconVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <HerowLocationBeacon/PublicHeader.h>
