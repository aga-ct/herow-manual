//
//  ConnectPlaceCommon.h
//  ConnectPlaceCommon
//
//  Created by Connecthings on 28/06/2017.
//  Copyright © 2017 Connecthings. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for ConnectPlaceCommon.
FOUNDATION_EXPORT double ConnectPlaceCommonVersionNumber;

//! Project version string for ConnectPlaceCommon.
FOUNDATION_EXPORT const unsigned char ConnectPlaceCommonVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <ConnectPlaceCommon/PublicHeader.h>



