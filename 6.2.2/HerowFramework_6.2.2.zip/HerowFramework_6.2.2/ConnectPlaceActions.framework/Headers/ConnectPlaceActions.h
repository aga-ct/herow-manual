//
//  ConnectPlaceActions.h
//  ConnectPlaceActions
//
//  Created by Connecthings on 18/08/2017.
//  Copyright © 2017 Connecthings. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for ConnectPlaceActions.
FOUNDATION_EXPORT double ConnectPlaceActionsVersionNumber;

//! Project version string for ConnectPlaceActions.
FOUNDATION_EXPORT const unsigned char ConnectPlaceActionsVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <ConnectPlaceActions/PublicHeader.h>
