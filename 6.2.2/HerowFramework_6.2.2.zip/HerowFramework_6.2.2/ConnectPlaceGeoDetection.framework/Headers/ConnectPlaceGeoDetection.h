//
//  ConnectPlaceGeoDetection.h
//  ConnectPlaceGeoDetection
//
//  Created by Connecthings on 09/01/2018.
//  Copyright © 2018 Connecthings. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for ConnectPlaceGeoDetection.
FOUNDATION_EXPORT double ConnectPlaceGeoDetectionVersionNumber;

//! Project version string for ConnectPlaceGeoDetection.
FOUNDATION_EXPORT const unsigned char ConnectPlaceGeoDetectionVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <ConnectPlaceGeoDetection/PublicHeader.h>


